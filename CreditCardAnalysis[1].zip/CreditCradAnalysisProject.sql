create database credit_transaction;
use credit_transaction;


CREATE TABLE customers (
     customer_id INT PRIMARY KEY,
     customer_name VARCHAR(255) NOT NULL,
     email VARCHAR(255) UNIQUE,  
     phone VARCHAR(20) UNIQUE,
     address TEXT   
); 

CREATE TABLE credit_cards ( 
		credit_card_id INT PRIMARY KEY,  
		card_number VARCHAR(16) UNIQUE NOT NULL,
        bank_name VARCHAR(100) NOT NULL,
        card_type VARCHAR(50)
        CHECK (card_type IN ('Debit', 'Credit', 'Prepaid')),
        customer_id INT,   
		FOREIGN KEY (customer_id) REFERENCES customers(customer_id)  
); 

CREATE TABLE transactions (
		transaction_id INT PRIMARY KEY, 
        credit_card_id INT,
        amount DECIMAL(10,2) NOT NULL CHECK (amount > 0),
        transaction_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        merchant VARCHAR(255),
        location VARCHAR(255),   
		FOREIGN KEY (credit_card_id) REFERENCES credit_cards(credit_card_id)  
); 

select *
from credit_transaction.customers;

select *
from credit_transaction.credit_cards;

select *
from credit_transaction.transaction_data;

select *
from credit_transaction.transaction_data
where credit_card_id= null;

-- CLEANING THE DATA

-- Find transactions where credit_card_id is missing.


select t1.*
from credit_transaction.transaction_data t1
left join credit_transaction.credit_cards c1
ON t1.credit_card_id= c1.credit_card_id
where c1.credit_card_id is null;

-- Identify credit cards that reference a non-existing customer.


select c1.*
from credit_cards c1
left join customers c2
ON c1.customer_id=c2.customer_id
where c1.customer_id is null;

-- Delete transactions with a missing or incorrect credit_card_id.

Delete from transaction_data where credit_card_id is null;

-- Remove credit cards linked to customers who don't exist in the customer table.

Delete from credit_cards where customer_id is null;



-- ANALYZING TRANSACTIONS:

-- How many tansactions happened?

select count(t1.transaction_id) as total_transactions
from transaction_data t1;

-- What is the total amount spent?

select sum(t1.amount_paid) as total_amount_paid
from transaction_data t1;

-- MONTHLY TRENDS:

-- How does spending change month by month?

select
month (t.transaction_date) as transaction_month, count(t.transaction_id) as total_transactions
from transaction_data t
group by month(t.transaction_date)
order by count(t.transaction_id) desc;

-- Who are the top 5 customers by total spending?


select c.customer_id,c1.first_name, c1.last_name, c.credit_card_id, x.total_amount_spent
from
(select credit_card_id, sum(transaction_amount) as total_amount_spent
from transaction_data
group by credit_card_id
order by sum(transaction_amount) desc
limit 5 ) x
left join credit_cards c
ON x.credit_card_id = c.credit_card_id
left join customers c1
ON c.customer_id= c1.customer_id
group by c.customer_id,c1.first_name,c1.last_name, c.credit_card_id, x.total_amount_spent;

-- Which bank's credit cards are used the most?

select c1.credit_card_id, c1.bank_name, x.cards_used
from
(select credit_card_id, count(credit_card_id) as cards_used
from transaction_data
group by credit_card_id
order by count(credit_card_id) desc
limit 1) x
left join credit_cards c1
ON x.credit_card_id=c1.credit_card_id
group by c1.credit_card_id, c1.bank_name, x.cards_used;

-- BUSINESS INSIGHTS

-- Customers with the highest spending.

select c.first_name, c.last_name, avg(t.transaction_amount) as average_transaction_amount
from transaction_data t
left join credit_cards c1
ON t.credit_card_id=c1.credit_card_id
left join customers c
ON c1.customer_id=c.customer_id
group by c.first_name, c.last_name
order by avg(t.transaction_amount) desc;



-- Banks with highest transactions

select c.bank_name, sum(t.transaction_amount) as total_transaction
from transaction_data t
left join credit_cards c
ON c.credit_card_id=t.credit_card_id
group by c.bank_name
order by total_transaction desc
limit 5;

-- Identifying peak spending times

select
hour(t.transaction_time) as transaction_hour, count(t.transaction_id) as total_transactions
from transaction_data t
group by hour(t.transaction_time)
order by count(t.transaction_id) desc;

